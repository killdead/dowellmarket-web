<?php
/**
 * css.php
 * Author: Federico Mestrone
 * Created: 14/12/2012 17:36
 * Copyright: 2012, Moodsdesign Ltd
 */
?>
.elgg-state-version_check {
    background-color: yellow;
    color: black;
}