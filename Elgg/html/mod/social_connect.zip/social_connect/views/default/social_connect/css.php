
/*
* Social Connect CSS for Site Connect
*/
.ha_connect_with_provider {
}
.ha_connect_with_provider img {	
}
.social_connect_site_connect {
	padding:10px;
	padding-top:0px;
	margin-top:0px;
}
.social_connect_site_connect div {
	padding:10px;
	padding-left:0px;
}
.social_connect_site_connect p {
	border-top:1px dotted #999;
	font-size: 10px;
}