= User settings remove =
Simple plugin for demonstrating Elgg-functionality.

== Contents ==
1. Features
2. ToDo

== 1. Features ==

- Remove "settings" from topbar menu
- Enable "settings" on profile page

== 2. ToDo ==
- test
- discuss