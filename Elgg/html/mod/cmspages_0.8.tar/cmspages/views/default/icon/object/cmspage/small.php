<?php
	echo $vars['url'] . "mod/pages/images/pages.gif";
?>