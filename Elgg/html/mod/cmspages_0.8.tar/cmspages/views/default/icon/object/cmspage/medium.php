<?php
	echo $vars['url'] . "mod/pages/images/pages_lrg.gif";
?>