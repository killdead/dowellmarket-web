CREDITS
=========
The development of this plugin was commissioned by Butterfly Media (The Netherlands) for the website:

[http://www.detrotsvanhetzuiden.com/][1]


INSTRUCTIONS
==============
To get this plugin working, go to the admin settings and enter a 
metadatafield name which your special groups have and a metadatafield value.

Example:
- field name: featured_group
- field value: yes

Also since this plugin was made for [http://www.detrotsvanhetzuiden.com/][1] the CSS is based on their theme.
To get the Group CSS working for your theme edit:
[mod_dir]/group_custom_layout/views/default/group_custom_layout/group/css.php

TO DO:
---------
- center custom color input fields

[1]: http://www.detrotsvanhetzuiden.com/