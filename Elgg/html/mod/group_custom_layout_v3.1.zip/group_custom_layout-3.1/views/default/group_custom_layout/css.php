<?php ?>

#colorpicker_container {
	display: none;
	width: 100%;
}

#background_container {
	display: none;
}

#colorpicker_container label {
	text-align: center;
	display: block;
}

.farbtastic {
	margin: 0 auto;
}

a.thickbox {
	display: none;
}