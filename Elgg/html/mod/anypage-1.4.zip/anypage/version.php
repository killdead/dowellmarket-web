<?php
/**
 * AnyPage Version
 */

$version = 2012083000;