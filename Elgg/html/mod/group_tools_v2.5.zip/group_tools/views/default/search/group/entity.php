<?php

	echo elgg_view_entity($vars["entity"]);