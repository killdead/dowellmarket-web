Name : Contact Us
Description : Adds the option for users to send message and for admins to check it out
Author : RiverVanRain [http://weborganizm.org/creator/rivervanrain]
Web : http://weborganizm.org/crewz/p/1983/personal-net
License : GNU General Public License version 2
Copyright : weborganiZm 2k13